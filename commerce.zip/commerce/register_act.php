<?php 
include 'config.php';
$kode=$_POST['kode'];
$nama=$_POST['nama'];
$jk=$_POST['jk'];
$templhr=$_POST['templhr'];
$tgllhr=$_POST['tgllhr'];
$alamat=$_POST['alamat'];
$nohp=$_POST['nohp'];
$email=$_POST['email'];
$user=$_POST['username'];
$pass=$_POST['password'];
$filenm = "fotoprofil/no-photo.jpg";
$hariini= date('Y-m-d');

$periksa=mysql_query("select * from member");
$no=1;
while($q=mysql_fetch_array($periksa)){
$email1=$q['email'];
$user1=$q['username'];}
if($email==$email1){
echo "	<script>alert('email sudah terdaftar');
			window.location.href='register.php';
			</script>";
}elseif($user==$user1) {
echo "	<script>alert('username sudah terdaftar');
			window.location.href='register.php';
			</script>";
}elseif($tgllhr>=$hariini) {				
echo "	<script>alert('tanggal belum tersedia');
			window.location.href='register.php';
			</script>";
} else {	
mysql_query("insert into member values('$kode',
										'$nama',
										'$jk',
										'$templhr',
										'$tgllhr',
										'$alamat',
										'$nohp',
										'$email',
										'$user',
										'$pass',
										'$filenm',
										NOW(),'Aktif')") or die ("<script>alert('Gagal melakukan registrasi'); window.location =  'register.php' </script>");
										echo "<script>alert('Berhasil melakukan registrasi'); window.location = 'index.php' </script>";

}
 ?>