<?php session_start();
include 'config.php';
$user=$_POST['user'];
$kode=$_POST['kode'];
$jumlah=$_POST['num-product'];
$size=$_POST['size'];

if($jumlah<1){
echo "Qty tidak boleh kosong";
}

if(isset($_SESSION['kodemember'])){

$jumlah_record=mysql_query("SELECT COUNT(*) FROM pemesanan_temp WHERE kodemember='$user' AND kode_produk='$kode' AND ukuran='$size'");
$jum=mysql_result($jumlah_record, 0);

if($jum==1){
mysql_query("UPDATE pemesanan_temp set jumlah=jumlah+$jumlah where kodemember='$user' AND kode_produk='$kode' AND ukuran='$size'");
echo "	<script>alert('Berhasil input ke keranjang');
			window.location.href='product.php';
			</script>";
} else{
mysql_query("insert into pemesanan_temp values('$user','$kode','$jumlah','$size')");
echo "	<script>alert('Berhasil input ke keranjang');
			window.location.href='product.php';
			</script>";
}
}else{
echo "	<script>alert('Harus login terlebih dahulu');
			window.location.href='index.php';
			</script>";
			}
 ?>