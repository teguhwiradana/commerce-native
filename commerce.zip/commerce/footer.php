<!-- Footer ================================================================== -->
	<div  id="footerSection">
	<div class="container">
		<div class="row">
			<!--<div class="span3">
				<h5>SISI JAKSA</h5>
				<!--<p><img src="img/my-home-button_59883.png" width="20" height="20" /> Indonesia</p>
				<p><img src="img/37-Telephone-512.png" width="20" height="20" /> 081234567890</p>
				<p><img src="img/580b57fcd9996e24bc43c543.png" width="20" height="20" /> 081234567890</p>
				<p><img src="img/mail-1454731_640.png" width="20" height="20" /> sisi.jaksa@gmail.com</p>
			 </div>
			<!--<div class="span3">
				<h5>INFO PENGIRIMAN</h5>
				<p>Pengiriman pesanan 1x24 jam via JNE / Wahana</p>  
				<img src="img/jne-resmi-naikkan-ongkos-kirim-20-persen.jpg" width="100" height="40" style="border-radius: 10px 10px 10px 10px;" /> 
				<img src="img/logo-wahana-white-319-x-139-wahana-harapan-indah-ekspedisi.jpg" width="100" height="60" style="border-radius: 10px 10px 10px 10px;"/> 
			 </div>
			<div class="span3">
				<h5>INFO PEMBAYARAN</h5>
				<p>Pembayaran via BNI (Kode Bank 009)</p>
				<img src="img/bni.png" width="100" height="40" style="border-radius: 10px 10px 10px 10px;" />
			 </div>
			<div id="socialMedia" class="span3 pull-right">
				<h5>SOCIAL MEDIA </h5>
				<a href="#"><img width="60" height="60" src="themes/images/facebook.png" title="facebook" alt="facebook"/></a>
				<a href="#"><img width="60" height="60" src="themes/images/twitter.png" title="twitter" alt="twitter"/></a>
				<a href="#"><img width="60" height="60" src="themes/images/youtube.png" title="youtube" alt="youtube"/></a>
			 </div> 
		 </div>-->
		<p class="pull-right">&copy; REMPEYEK ILHAM 2022</p>
	</div><!-- Container End -->
	</div>