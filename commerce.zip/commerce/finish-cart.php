<?php 
session_start();
include 'config.php';

//membuat kodepemesanan
$query = mysql_query("Select right(max(kodepemesanan),6) from pemesanan where kodepemesanan like 'INV%'");
$result = mysql_fetch_array($query);
$jumlahrow = mysql_num_rows($query);
if ($jumlahrow == 0){
$kodepemesanan = "INV000001";
}else{
$kodepemesanan = "INV" . str_pad(strval($result[0] + 1),6,"0",STR_PAD_LEFT);
}

//menghitung total produk di pemesanan sementara
$jumlah_record=mysql_query("SELECT COUNT(*) from pemesanan_temp");
$jum=mysql_result($jumlah_record, 0);


// simpan data pemesanan 
$wilayah=$_POST['wilayah'];
$total=$_POST['total'];
mysql_query("INSERT INTO pemesanan(kodepemesanan, kodemember, kodewilayah, total, status, tanggalpemesanan, noresi)
VALUES ('$kodepemesanan','$_SESSION[kodemember]','$wilayah','$total','Pesanan Baru',NOW(),'-')");
  
// simpan data detail pemesanan  
$sql = mysql_query("SELECT * FROM pemesanan_temp WHERE kodemember='$_SESSION[kodemember]'");
$j=1;
while ($r=mysql_fetch_array($sql)) {
$kode_produk[$j]=$r['kode_produk'];
$jumlah[$j]=$r['jumlah'];
$ukuran[$j]=$r['ukuran'];
mysql_query("INSERT INTO pemesanan_detail(no,kodepemesanan, kode_produk, jumlah, size) VALUES('','$kodepemesanan', '$kode_produk[$j]', '$jumlah[$j]','$ukuran[$j]')") or mysql_error();
mysql_query("UPDATE produk SET stok= stok - '$jumlah[$j]' WHERE kode_produk='$kode_produk[$j]'");
$j++; 
}
   
// setelah data pemesanan tersimpan, hapus data pemesanan sementara
for ($i = 0; $i < $jum; $i++)
{
mysql_query("DELETE FROM pemesanan_temp WHERE kodemember = '$_SESSION[kodemember]'");
}

echo "<script>alert('Berhasil Melakukan Pemesanan');
window.location.href='detailpesanan.php?kode=$kodepemesanan';
			  </script>";
		
?>
          		