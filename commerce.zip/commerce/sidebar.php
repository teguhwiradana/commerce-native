<!-- Sidebar ================================================== -->
	<div id="sidebar" class="span3">
		<div class="well well-small"><a id="myCart" href="product.php">Kategori  <span class="pull-right"></span></a></div>
		<ul id="sideManu" class="nav nav-tabs nav-stacked">
			<?php 	$sql=mysql_query("select * from kategori");
			  	while($r=mysql_fetch_array($sql)){ 
				$kode=$r['id_kategori'];?>
			<li class="subMenu"><a href="product1.php?id=<?php echo $r['id_kategori']; ?>"> <?php echo $r['nama_kategori'];?></a>
				<ul style="display:none">
                <?php 	$sql1=mysql_query("select * from subkategori where id_kategori='$kode'");
			  	while($r1=mysql_fetch_array($sql1)){ ?>
				<li><a href="product2.php?id=<?php echo $r1['id_subkategori']; ?>"><i class="icon-chevron-right"></i><?php echo $r1['nama_subkategori'];?> </a></li>
                <?php } ?>
				</ul>
			</li>
        <?php } ?>
		</ul>
		<br/>
			<!--<div class="thumbnail">
				<img src="img/bni.png" title="Bootshop Payment Methods" alt="Payments Methods">
				<div class="caption">
				  <h5>Payment Methods</h5>
				</div>
			  </div>-->
	</div>
<!-- Sidebar end=============================================== -->