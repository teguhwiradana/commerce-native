<?php include ('title.php');?>
<?php include ('header.php');?>
<div id="mainBody">
	<div class="container">
	<div class="row">
<?php include('sidebar.php');?>
	<div class="span9" id="mainCol">
    <ul class="breadcrumb">
		<li><a href="index.php">Beranda</a> <span class="divider">/</span></li>
        <li><a href="lihatpesanan.php">Lihat Pesanan</a> <span class="divider">/</span></li>
		<li class="active">Lihat Detail Pesanan</li>
    </ul>
	<h3> Lihat Detail Pesanan</h3>	
	<hr class="soft"/>
 <?php $sql=mysql_query("select p.*, w.* FROM pemesanan p left join wilayah w on w.kodewilayah=p.kodewilayah where kodepemesanan='$_GET[kode]'")or die(mysql_error());
while($d=mysql_fetch_array($sql)){
$total= $d['total'];
$wilayah=$d['kodewilayah'];
	?>		
					<!-- Product -->
					<div class="row">
<table class="table table-striped">
				<tbody>
				<tr class="techSpecRow">
                <td><b>No Invoice</b></td>
                <td width="65%">: <?php echo $d['kodepemesanan'];?></td>
                </tr>
				<tr class="techSpecRow">
                <td><b>Status Pesanan</b></td>
                <td width="65%">: <?php echo $d['Status'];?></td>
                </tr>
                <tr class="techSpecRow">
                <td><b>Tanggal Pemesanan</b></td>
                <td width="65%">: <?php echo $d['TanggalPemesanan'];?></td>
                </tr>
                <tr class="techSpecRow">
                <td><b>Jasa Pengiriman</b></td>
                <?php $jp=$d['kodejp']; $sql1=mysql_query("select * from jasakirim where kodejp='$jp'");
									while($hasil1=mysql_fetch_array($sql1)){?>
                <td width="65%">: <?php echo $hasil1['namajp'];?></td>
                <?php } ?>
                </tr>
                <tr class="techSpecRow">
                <td><b>No Resi</b></td>
                <td width="65%">: <?php echo $d['noresi'];?></td>
                </tr>
				</tbody>
</table>
<?php } ?>
                <hr>
			<table class="table table-bordered table-hover table-condensed">
    <tr align="center">
        <td><b>Nama Produk</b></td>
        <td><b>Harga</b></td>
        <td><b>Qty</b></td>
        <td><b>Size</b></td>
        <td><b>Harga Barang</b></td>
    </tr>
<?php $sql1=mysql_query("select pm.*, p.* from pemesanan_detail pm left join produk p on p.kode_produk=pm.kode_produk where kodepemesanan='$_GET[kode]'")or die(mysql_error());
while($r=mysql_fetch_array($sql1)){
$hargabarang=0;
$hargabarang= $r['jumlah']*$r['harga_barang'];
	?>	
<tr class="active">
        <td align="center"><?php echo $r['nama_barang'];?></td>
        <td align="center">Rp <?php echo number_format($r['harga_barang']);?>,-</td>
        <td align="center"><?php echo $r['jumlah'];?></td>
        <td align="center"><?php echo $r['size'];?></td>
        <td align="center">Rp <?php echo number_format($hargabarang);?>,-</td>
</tr>
<?php } ?>
<tr>
<td colspan="4" align="right"><b>Harga Subtotal</b></td>
<td><b>Rp <?php echo number_format($total);?>,-</b> </td>
</tr>
<tr>
<td colspan="4" align="right"><b>Harga Ongkir</b></td>
<?php $sql1=mysql_query("select * from wilayah where kodewilayah='$wilayah'")or die(mysql_error());
while($w=mysql_fetch_array($sql1)){
$ongkir= $w['ongkir'];?>
<td><b>Rp <?php echo number_format($ongkir);?>,-</b> </td>
<?php } ?>
</tr>
<tr>
<td colspan="4" align="right"><b>Harga Total</b></td>
<td><b>Rp <?php $hargatotal=0; $hargatotal=$ongkir + $total; echo number_format($hargatotal);?>,-</b> </td>
</tr>
<!--
<tr>
        <td colspan="5" align="center">Maaf Informasi pesanan belum tersedia</td>
</tr>
-->
</table>
				
					</div>
</div>
</div></div>
</div>
<!-- MainBody End ============================= -->
<?php include('footer.php');?>
<!-- Placed at the end of the document so the pages load faster ============================================= -->
	<script src="themes/js/jquery.js" type="text/javascript"></script>
	<script src="themes/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="themes/js/google-code-prettify/prettify.js"></script>
	
	<script src="themes/js/bootshop.js"></script>
    <script src="themes/js/jquery.lightbox-0.5.js"></script>
	
	<!-- Themes switcher section ============================================================================================= -->
<div id="secectionBox">
<link rel="stylesheet" href="themes/switch/themeswitch.css" type="text/css" media="screen" />
<script src="themes/switch/theamswitcher.js" type="text/javascript" charset="utf-8"></script>
	<div id="themeContainer">
	<div id="hideme" class="themeTitle">Style Selector</div>
	<div class="themeName">Oregional Skin</div>
	<div class="images style">
	<a href="themes/css/#" name="bootshop"><img src="themes/switch/images/clr/bootshop.png" alt="bootstrap business templates" class="active"></a>
	<a href="themes/css/#" name="businessltd"><img src="themes/switch/images/clr/businessltd.png" alt="bootstrap business templates" class="active"></a>
	</div>
	<div class="themeName">Bootswatch Skins (11)</div>
	<div class="images style">
		<a href="themes/css/#" name="amelia" title="Amelia"><img src="themes/switch/images/clr/amelia.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="spruce" title="Spruce"><img src="themes/switch/images/clr/spruce.png" alt="bootstrap business templates" ></a>
		<a href="themes/css/#" name="superhero" title="Superhero"><img src="themes/switch/images/clr/superhero.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="cyborg"><img src="themes/switch/images/clr/cyborg.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="cerulean"><img src="themes/switch/images/clr/cerulean.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="journal"><img src="themes/switch/images/clr/journal.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="readable"><img src="themes/switch/images/clr/readable.png" alt="bootstrap business templates"></a>	
		<a href="themes/css/#" name="simplex"><img src="themes/switch/images/clr/simplex.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="slate"><img src="themes/switch/images/clr/slate.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="spacelab"><img src="themes/switch/images/clr/spacelab.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="united"><img src="themes/switch/images/clr/united.png" alt="bootstrap business templates"></a>
		<p style="margin:0;line-height:normal;margin-left:-10px;display:none;"><small>These are just examples and you can build your own color scheme in the backend.</small></p>
	</div>
	<div class="themeName">Background Patterns </div>
	<div class="images patterns">
		<a href="themes/css/#" name="pattern1"><img src="themes/switch/images/pattern/pattern1.png" alt="bootstrap business templates" class="active"></a>
		<a href="themes/css/#" name="pattern2"><img src="themes/switch/images/pattern/pattern2.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern3"><img src="themes/switch/images/pattern/pattern3.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern4"><img src="themes/switch/images/pattern/pattern4.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern5"><img src="themes/switch/images/pattern/pattern5.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern6"><img src="themes/switch/images/pattern/pattern6.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern7"><img src="themes/switch/images/pattern/pattern7.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern8"><img src="themes/switch/images/pattern/pattern8.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern9"><img src="themes/switch/images/pattern/pattern9.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern10"><img src="themes/switch/images/pattern/pattern10.png" alt="bootstrap business templates"></a>
		
		<a href="themes/css/#" name="pattern11"><img src="themes/switch/images/pattern/pattern11.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern12"><img src="themes/switch/images/pattern/pattern12.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern13"><img src="themes/switch/images/pattern/pattern13.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern14"><img src="themes/switch/images/pattern/pattern14.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern15"><img src="themes/switch/images/pattern/pattern15.png" alt="bootstrap business templates"></a>
		
		<a href="themes/css/#" name="pattern16"><img src="themes/switch/images/pattern/pattern16.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern17"><img src="themes/switch/images/pattern/pattern17.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern18"><img src="themes/switch/images/pattern/pattern18.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern19"><img src="themes/switch/images/pattern/pattern19.png" alt="bootstrap business templates"></a>
		<a href="themes/css/#" name="pattern20"><img src="themes/switch/images/pattern/pattern20.png" alt="bootstrap business templates"></a>
		 
	</div>
	</div>
</div>
<span id="themesBtn"></span>
</body>
</html>