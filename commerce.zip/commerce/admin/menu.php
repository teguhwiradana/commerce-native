<nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li class="text-center user-image-back">
                        <img src="assets/img/LOGO(1).png" class="img-responsive" />
                     
                    </li>


                    <li>
                        <a href="dashboard.php"><i class="fa fa-desktop "></i>Dashboard</a>
                    </li>
                    

                    <li>
                        <a href="admin.php"><i class="fa fa-table "></i>Admin</a>
                    </li>
                    <li>
                        <a href="pelanggan.php"><i class="fa fa-table "></i>Pelanggan</a>
                    </li>
                    <li>
                        <a href="infotoko.php"><i class="fa fa-table "></i>Profil Toko</a>
                    </li>
                    <li>
                        <a href="kategori.php"><i class="fa fa-table "></i>Kategori</a>
                    </li>
                    <li>
                        <a href="barang.php"><i class="fa fa-table "></i>Data Barang</a>
                    </li>
                    <!--<li>
                        <a href="jasapengiriman.php"><i class="fa fa-table "></i>Jasa Pengiriman</a>
                    </li>-->
                    <li>
                        <a href="bank.php"><i class="fa fa-table "></i>Bank</a>
                    </li>
                    <li>
                        <a href="pemesanan.php"><i class="fa fa-table "></i>Pemesanan</a>
                    </li>
                    <!--<li>
                        <a href="penjualan.php?page=penjualan&act=tambah"><i class="fa fa-table "></i>Entry Penjualan</a>
                    </li>-->
					
                    <li><a class="dropdown-toggle" data-toggle="dropdown" role="button" href="laporan.php">
						Laporan</a>
						<ul class="dropdown-menu">
							<li> <a href="laporanproduk.php">Laporan Produk</a></li>
							<li> <a href="laporanpelanggan.php">Laporan Pelanggan</a></li>
							<li> <a href="laporantransaksi2.php">Laporan Transaksi</a></li>
							<!-- <li> <a href="laporantransfer2.php">Laporan Transfer</a></li> -->
						</ul>
                    </li>
                    <!--
                    <li>
                        <a href="#"><i class="fa fa-edit "></i>UI Elements<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="#">Notifications</a>
                            </li>
                            <li>
                                <a href="#">Elements</a>
                            </li>
                            <li>
                                <a href="#">Free Link</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-edit "></i>Forms </a>
                    </li>


                    <li>
                        <a href="#"><i class="fa fa-sitemap "></i>Multi-Level Dropdown<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="#">Second Level Link</a>
                            </li>
                            <li>
                                <a href="#">Second Level Link</a>
                            </li>
                            <li>
                                <a href="#">Second Level Link<span class="fa arrow"></span></a>
                                <ul class="nav nav-third-level">
                                    <li>
                                        <a href="#">Third Level Link</a>
                                    </li>
                                    <li>
                                        <a href="#">Third Level Link</a>
                                    </li>
                                    <li>
                                        <a href="#">Third Level Link</a>
                                    </li>

                                </ul>

                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-qrcode "></i>Tabs & Panels</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-bar-chart-o"></i>Mettis Charts</a>
                    </li>

                    <li>
                        <a href="#"><i class="fa fa-edit "></i>Last Link </a>
                    </li>
                    <li>
                        <a href="blank.html"><i class="fa fa-table "></i>Blank Page</a>
                    </li>
                    -->
                </ul>

            </div>

        </nav>
        <!-- /. NAV SIDE  -->