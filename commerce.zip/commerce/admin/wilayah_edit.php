<?php include ('title.php');?>
<body>
    <div id="wrapper">
        
<?php include ('header.php');?>
        
<?php include ('menu.php');
$id_kode=mysql_real_escape_string($_GET['kode']);?>
        
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Edit Wilayah</h2>
                    </div>
                </div>
<a class="btn" href="wilayah.php?id=<?php echo $id_kode;?>"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>
<?php
$id_wilayah=mysql_real_escape_string($_GET['id']);
$det=mysql_query("select * from wilayah where kodewilayah='$id_wilayah'")or die(mysql_error());
while($d=mysql_fetch_array($det)){
?>					
	<form action="wilayah_update.php" method="post">
		<table class="table">    
			<tr>
				<td width="20%">Jasa Pengiriman</td>
				<td><select name="jasapengiriman" id="jasapengiriman" class="form-control" onChange="tampilkan()">
                				  <option value='<?php echo $d['kodejp']; ?>'>- Pilih Jasa Pengiriman -</option>
								  <?php
                                  		$prov = mysql_query("SELECT * FROM jasakirim");
										while($hasil = mysql_fetch_array($prov)){ ?>
										<option value='<?php echo $hasil['kodejp']; ?>'><?php echo $hasil['namajp']; ?></option>
								  <?php } ?>                                                              
                     </select>
                </td>
			</tr>
            <tr>
				<td>Nama Wilayah</td>
				<td>
                <input name="id" type="hidden" class="form-control" value="<?php echo $_GET['kode'];?>"/>
                <input type="hidden" class="form-control" name="id_wilayah" value="<?php echo $id_wilayah; ?>">
                <input type="text" class="form-control" name="nama" value="<?php echo $d['namawilayah']; ?>"></td>
			</tr>
            <tr>
				<td>Ongkos Kirim</td>
				<td><input type="text" class="form-control" name="ongkir" value="<?php echo $d['ongkir']; ?>"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" class="btn btn-info" value="Simpan"></td>
			</tr>
		</table>
	</form>
	<?php 
}
?>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
