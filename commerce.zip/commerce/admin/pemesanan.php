<?php include ('title.php');?>
<body>
    <div id="wrapper">
        
<?php include ('header.php');?>
        
<?php include ('menu.php');?>
        
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Data Pemesanan</h2>

<br/>
                    </div>
                </div>
  <?php 
$per_hal=10;
$jumlah_record=mysql_query("SELECT COUNT(*) from pemesanan");
$jum=mysql_result($jumlah_record, 0);
$halaman=ceil($jum / $per_hal);
$page = (isset($_GET['page'])) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $per_hal;
?>
<div class="col-md-12">
	<table class="col-md-2">
		<tr>
			<td>Jumlah Record</td>		
			<td><?php echo $jum; ?></td>
		</tr>
		<tr>
			<td>Jumlah Halaman</td>	
			<td><?php echo $halaman; ?></td>
		</tr>
	</table>
</div>

<br/>
<table class="table table-bordered">
    <thead align="center">
        <th>No Invoice</th>
        <th>Tanggal Pemesanan</th>
        <th>Status Pemesanan</th>
        <th>Aksi</th>
    </thead>

<?php $sql = mysql_query("SELECT * FROM pemesanan");
	  while($hasil = mysql_fetch_array($sql)){ 
?>
 <tr class="active">
        <td align="center"><?php echo $hasil['kodepemesanan'];?></td>
        <td align="center"><?php echo $hasil['TanggalPemesanan'];?></td>
        <td align="center"><?php echo $hasil['Status'];?></td>
        <td align="center">
        <a class="btn btn-primary"href="detailpesanan.php?kode=<?php echo $hasil['kodepemesanan'];?>"> Detail </a>
        <!--
        <a class="btn btn-primary"href="konfirmasi_penerimaan.php"> Konfirmasi Penerimaan</a>
        -->
        </tr>
        <?php } ?>

<!--
<tr>
        <td colspan="5" align="center">Maaf Informasi pesanan belum tersedia</td>
</tr>
-->
</table>
<ul class="pagination">			
			<?php 
			for($x=1;$x<=$halaman;$x++){
				?>
				<li><a href=""><?php echo $x ?></a></li>
				<?php
			}
			?>						
		</ul>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
