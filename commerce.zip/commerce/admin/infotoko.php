<?php include ('title.php');?>
<body>
    <div id="wrapper">
        
<?php include ('header.php');?>
        
<?php include ('menu.php');?>
        
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Data Admin </h2>
                    </div>
                </div>
<h3><span class="glyphicon glyphicon-list-alt"></span>  Profil Toko</h3>

<?php
$det=mysql_query("select * from infotoko where kodeinfo='PD001'")or die(mysql_error());
while($d=mysql_fetch_array($det)){
	?>					
<form action = "infotoko_simpan.php" method="POST" >
<textarea name="kontak"><?php echo base64_decode($d["info"]); ?></textarea>
<input type="submit" value ="Simpan" /> <input type="reset" value ="Batal" /> <a href = "../profil.php" target = "_blank"  >Lihat Info Toko</a>
</form>
<?php } ?>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
