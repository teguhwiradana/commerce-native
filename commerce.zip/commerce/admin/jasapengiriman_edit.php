<?php include ('title.php');?>
<body>
    <div id="wrapper">
        
<?php include ('header.php');?>
        
<?php include ('menu.php');?>
        
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Edit Jasa Pengiriman</h2>
                    </div>
                </div>
<a class="btn" href="jasapengiriman.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>
<?php
$id_jp=mysql_real_escape_string($_GET['id']);
$det=mysql_query("select * from jasakirim where kodejp='$id_jp'")or die(mysql_error());
while($d=mysql_fetch_array($det)){
?>					
	<form action="jasapengiriman_update.php" method="post">
		<table class="table">
            <tr>
				<td width="20%">Nama Jasa pengiriman</td>
				<td>
                <input type="hidden" class="form-control" name="id_jp" value="<?php echo $id_jp; ?>">
                <input type="text" class="form-control" name="nama" value="<?php echo $d['namajp']; ?>"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" class="btn btn-info" value="Simpan"></td>
			</tr>
		</table>
	</form>
	<?php 
}
?>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
