<?php 
	session_start();
	include 'cek.php';
	?>
<?php include('config.php');?>
<div class="navbar navbar-inverse navbar-fixed-top">
            <div class="adjust-nav">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#"><i class="fa fa-square-o "></i>&nbsp;REMPEYEK ILHAM</a>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                    <li><a href="#"><?php $namahari = array("Minggu","Senin","Selasa","Rabu","Kamis","Jum'at","Sabtu"); 
			$namabulan = array("","Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember");
			echo $namahari[date("w")].", ".date("j")." ".$namabulan[date("n")]." ".date("Y"); ?></a></li>
                        <li><a class="dropdown-toggle" data-toggle="dropdown" role="button" href="#">Hallo, 
					<?php 
					$username=$_SESSION['username'];
					$mysql="select * from admin where username='$username'";
					$rs=mysql_query($mysql);
					while ($row=mysql_fetch_array($rs)){
					echo $row['nama_lengkap'];
					} ?>
                    &nbsp&nbsp<span class="glyphicon glyphicon-user"></span></a>
                    <ul class="dropdown-menu">
                    	<li><a href="admin_edit.php"><span class="glyphicon glyphicon-user"></span> Edit Profil</a></li>
                        <li><a href="ganti_pass.php"><span class="glyphicon glyphicon-lock"></span> Ganti Password</a></li>
                        <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
                    </ul>
                    </li>
                    </ul>
                </div>

            </div>
        </div>