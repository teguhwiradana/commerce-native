<?php include ('title.php');?>
<body>
    <div id="wrapper">
        
<?php include ('header.php');?>
        
<?php include ('menu.php');?>
        
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Data Pemesanan</h2>

<br/>
                    </div>
                </div>
<?php $sql=mysql_query("select * from pemesanan where kodepemesanan='$_GET[kode]'")or die(mysql_error());
while($d=mysql_fetch_array($sql)){
$total= $d['total'];
$member=$d['kodemember'];
$wilayah=$d['kodewilayah'];
	?>		
					<!-- Product -->
					<div class="row">
                    <form action="konfirmasi_pesanan.php" method="post">
<table class="table table-striped">
				<tbody>
				<tr class="techSpecRow">
                <td><b>No Invoice</b></td>
                <td width="65%">: <input name="kdpsn" type="hidden" value="<?php echo $d['kodepemesanan'];?>">
				<?php echo $d['kodepemesanan'];?></td>
                </tr>
                <tr class="techSpecRow">
                <td><b>Nama Pemesan</b></td>
                <td width="65%">: 
                <?php $sql1=mysql_query("select * from member where kodemember='$member'")or die(mysql_error());
while($d1=mysql_fetch_array($sql1)){ ?>
				<?php echo $d1['namamember'];}?></td>
                </tr>
                <tr class="techSpecRow">
                <td><b>Alamat Pemesan</b></td>
                <td width="65%">: 
                <?php $sql1=mysql_query("select * from member where kodemember='$member'")or die(mysql_error());
while($d1=mysql_fetch_array($sql1)){ ?>
				<?php echo $d1['alamat'];}?></td>
                </tr>
				<tr class="techSpecRow">
                <td><b>Status Pesanan</b></td>
                <td width="65%">:
                <select name="status">
                <?php
				if ($d['Status'] == "Pesanan Baru") echo "<option value = 'Pesanan Baru' selected>Pesanan Baru</option>";
				else echo "<option value='Pesanan Baru'>Pesanan Baru</option>";
				if ($d['Status'] == "Menunggu Konfirmasi") echo "<option value = 'Menunggu Konfirmasi' selected>Menunggu Konfirmasi</option>";
				else echo "<option value='Menunggu Konfirmasi'>Menunggu Konfirmasi</option>";
				if ($d['Status'] == "Telah di Konfirmasi") echo "<option value = 'Telah di Konfirmasi' selected>Telah di Konfirmasi</option>";
				else echo "<option value='Telah di Konfirmasi'>Telah di Konfirmasi</option>";
				//if ($d['Status'] == "Pesanan di Kirim") echo "<option value = 'Pesanan di Kirim' selected>Pesanan di Kirim</option>";
				//else echo "<option value='Pesanan di Kirim'>Pesanan di Kirim</option>"; ?>
                </select> </td>
                </tr>
                <!--<tr class="techSpecRow">
                <td><b>Input Resi</b></td>
                <td width="65%">: <input name="resi" type="text" value=""></td>
                </tr>-->
                <tr class="techSpecRow">
                <td><b>Tanggal Pemesanan</b></td>
                <td width="65%">: <?php echo $d['TanggalPemesanan'];?></td>
                </tr>
                <tr class="techSpecRow">
                <td><b>Bukti Pembayaran</b></td>
                <?php 
						$jumlah_record=mysql_query("SELECT COUNT(*) from konfirmasi where kodepemesanan='$_GET[kode]'");
						$jum=mysql_result($jumlah_record, 0);
						if($jum==0){?>
                <td width="65%">: Pelanggan belum melakukan pembayaran</td>
                <?php } else { ?>
                <td width="65%"> :
                <?php        
						$sql1=mysql_query("select * from konfirmasi where kodepemesanan='$_GET[kode]'")or die(mysql_error());
						while($d1=mysql_fetch_array($sql1)){ $foto=$d1['fotobukti']; } ?>
				<img src="<?php echo $foto;?>" width="100" height="150"></td>
                <?php } ?>
                </tr>
                <tr class="techSpecRow">
                <td></td>
                <td width="65%"> <button type="submit">Simpan</button></td>
                </tr>
				</tbody>
</table>
</form>
<?php } ?>
                <hr>
			<table class="table table-bordered table-hover table-condensed">
    <tr align="center">
        <td><b>Nama Produk</b></td>
        <td><b>Harga</b></td>
        <td><b>Qty</b></td>
        <!--<td><b>Size</b></td>-->
        <td><b>Harga Barang</b></td>
    </tr>
<?php $sql1=mysql_query("select pm.*, p.* from pemesanan_detail pm left join produk p on p.kode_produk=pm.kode_produk where kodepemesanan='$_GET[kode]'")or die(mysql_error());
while($r=mysql_fetch_array($sql1)){
$hargabarang=0;
$hargabarang= $r['jumlah']*$r['harga_barang'];
	?>	
<tr class="active">
        <td align="center"><?php echo $r['nama_barang'];?></td>
        <td align="center">Rp <?php echo number_format($r['harga_barang']);?>,-</td>
        <td align="center"><?php echo $r['jumlah'];?></td>
        <!--<td align="center"><?php echo $r['size'];?></td>-->
        <td align="center">Rp <?php echo number_format($hargabarang);?>,-</td>
</tr>
<?php } ?>
<tr>
<td colspan="3" align="right"><b>Harga Subtotal</b></td>
<td><b>Rp <?php echo number_format($total);?>,-</b> </td>
</tr>
<tr>
<td colspan="3" align="right"><b>Harga Ongkir</b></td>
<?php $sql1=mysql_query("select * from wilayah where kodewilayah='$wilayah'")or die(mysql_error());
while($w=mysql_fetch_array($sql1)){
$ongkir= $w['ongkir'];?>
<td><b>Rp <?php echo number_format($ongkir);?>,-</b> </td>
<?php } ?>
</tr>
<tr>
<td colspan="3" align="right"><b>Harga Total</b></td>
<td><b>Rp <?php $hargatotal=0; $hargatotal=$ongkir + $total; echo number_format($hargatotal);?>,-</b> </td>
</tr>
<!--
<tr>
        <td colspan="5" align="center">Maaf Informasi pesanan belum tersedia</td>
</tr>
-->
</table>


            </div>


            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
