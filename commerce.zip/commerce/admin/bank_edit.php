<?php include ('title.php');?>
<body>
    <div id="wrapper">
        
<?php include ('header.php');?>
        
<?php include ('menu.php');?>
        
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Edit Bank</h2>
                    </div>
                </div>
<a class="btn" href="bank.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>
<?php
$id_bank=mysql_real_escape_string($_GET['id']);
$det=mysql_query("select * from bank where kodebank='$id_bank'")or die(mysql_error());
while($d=mysql_fetch_array($det)){
?>					
	<form action="bank_update.php" method="post">
		<table class="table">
            <tr>
				<td width="20%">Nama Bank</td>
				<td>
                <input type="hidden" class="form-control" name="id_bank" value="<?php echo $id_bank; ?>">
                <input type="text" class="form-control" name="nama" value="<?php echo $d['namabank']; ?>"></td>
			</tr>
            <tr>
				<td>Nama Pemilik Rekening</td>
				<td><input type="text" class="form-control" name="nprek" value="<?php echo $d['namapemilikakun']; ?>"></td>
			</tr>
            <tr>
				<td>Nomor Rekening</td>
				<td><input type="text" class="form-control" name="norek" value="<?php echo $d['rekening']; ?>"></td>
			</tr>

			<tr>
				<td></td>
				<td><input type="submit" class="btn btn-info" value="Simpan"></td>
			</tr>
		</table>
	</form>
	<?php 
}
?>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
