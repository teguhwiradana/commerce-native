<?php include ('title.php');?>
<body>
    <div id="wrapper">
        
<?php include ('header.php');?>
        
<?php include ('menu.php');?>
        
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Edit Subkategori</h2>
                    </div>
                </div>
<a class="btn" href="subkategori.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>
<?php
$id_subkategori=mysql_real_escape_string($_GET['id']);
$det=mysql_query("select * from subkategori where id_subkategori='$id_subkategori'")or die(mysql_error());
while($d=mysql_fetch_array($det)){
?>					
	<form action="subkategori_update.php" method="post">
		<table class="table">
            <tr>
				<td>Nama</td>
				<td>
                <input name="id" type="hidden" class="form-control" value="<?php echo $_GET['kode'];?>"/>
                <input type="hidden" class="form-control" name="id_subkategori" value="<?php echo $id_subkategori; ?>">
                <input type="text" class="form-control" name="nama" value="<?php echo $d['nama_subkategori']; ?>"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" class="btn btn-info" value="Simpan"></td>
			</tr>
		</table>
	</form>
	<?php 
}
?>

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
