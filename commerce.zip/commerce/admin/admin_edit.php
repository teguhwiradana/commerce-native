<?php include ('title.php');?>
<body>
    <div id="wrapper">
        
<?php include ('header.php');?>
        
<?php include ('menu.php');?>
        
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h2>Edit Admin</h2>
                    </div>
                </div>
                <!-- /. ROW  -->
	<?php 
if(isset($_GET['pesan'])){
	$pesan=mysql_real_escape_string($_GET['pesan']);
	if($pesan=="gagal"){
		echo "<div class='alert alert-danger'>Password gagal di ganti !!     Periksa Kembali Password yang anda masukkan !!</div>";
	}else if($pesan=="tdksama"){
		echo "<div class='alert alert-warning'>Password yang anda masukkan tidak sesuai  !!     silahkan ulangi !! </div>";
	}else if($pesan=="oke"){
		echo "<div class='alert alert-success'>Password yang anda masukkan tidak sesuai  !!     silahkan ulangi !! </div>";
	}
}
?>

<br/>
<div class="col-md-5 col-md-offset-3">
	<form action="admin_update.php" method="post">
		<div class="form-group">
        	<label>Username</label>
			<input name="user" readonly="1" class="form-control" value="<?php echo $_SESSION['username']; ?>">
		</div>
        <?php $id=$_SESSION['username'];
			  $periksa=mysql_query("select * from admin where username='$id'");
			  $no=1;
			  while($q=mysql_fetch_array($periksa)){ ?>
        <div class="form-group">
			<label>Nama Lengkap</label>
			<input name="nama" type="text" class="form-control" value="<?php echo $q['nama_lengkap'] ?>">
		</div>
        <div class="form-group">
			<label>Email</label>
			<input name="email" type="text" class="form-control" value="<?php echo $q['email'] ?>">
		</div>
        <div class="form-group">
			<label>No HP</label>
			<input name="nohp" type="text" class="form-control" value="<?php echo $q['no_telp'] ?>">
		</div>	
        <?php $no++;} ?>
		<div class="form-group">
			<label></label>
			<input type="submit" class="btn btn-info" value="Simpan">
			<input type="reset" class="btn btn-danger" value="reset">
		</div>																	
	</form>
</div>
                
                  

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>


</body>
</html>
