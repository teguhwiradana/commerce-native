<body>
<div id="header">
<div class="container">
<div id="welcomeLine" class="row">
    <?php  if(isset($_SESSION['kodemember'])){
											
											$query = mysql_query("select * from member where kodemember  = '$_SESSION[kodemember]'");
											$row = mysql_fetch_array($query);
										?>
     <?php 	$jumlah_record=mysql_query("SELECT COUNT(*) from pemesanan_temp where kodemember='$_SESSION[kodemember]'");
						$jum=mysql_result($jumlah_record, 0);?>
	<div class="span6">Selamat Datang<strong> <?php echo $_SESSION['namamember'];?></strong></div>
	<div class="span6">
    <div class="pull-right">

		<a href="cart.php"><span class="btn btn-mini btn-primary"><i class="icon-shopping-cart icon-white"></i> [ <?php echo $jum;?> ] barang di keranjang </span> </a> 
	</div>
    <?php }else{ ?>
    <div class="span6"></div>
	<div class="span6">
    <div class="pull-right">
    </div>
    <?php } ?>
	</div>
</div>
<!-- Navbar ================================================== -->
<div id="logoArea" class="navbar">
<a id="smallScreen" data-target="#topMenu" data-toggle="collapse" class="btn btn-navbar">
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
</a>
  <div class="navbar-inner">
    <a class="brand" href="index.php"><img src="img/LOGO.png" width="88" height="293"  style="border-radius: 10px 10px 10px 10px;"/></a>
		
    <ul id="topMenu" class="nav pull-right">
     <li class=""><a href="profile.php">Profil</a></li>
	 <li class=""><a href="product.php">Galeri</a></li>
	 <li class=""><a href="carabelanja.php">Cara Belanja</a></li>
     <li class=""><a href="contact.php">Hubungi Kami</a></li>
     <?php  if(isset($_SESSION['kodemember'])){
											
											$query = mysql_query("select * from member where kodemember  = '$_SESSION[kodemember]'");
											$row = mysql_fetch_array($query);
										?>
     <li class=""><a href="akun.php">Info Akun</a></li>
     <li class="">
	 <a href="logout.php" role="button" style="padding-right:0"><span class="btn btn-large btn-success">Logout</span></a>
      <?php }else{ ?>
	 <li class="">
	 <a href="#login" role="button" data-toggle="modal" style="padding-right:0"><span class="btn btn-large btn-success">Login</span></a>
	<div id="login" class="modal hide fade in" tabindex="-1" role="dialog" aria-labelledby="login" aria-hidden="false" >
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			<h3>Login</h3>
		  </div>
		  <div class="modal-body">
			<form class="form-horizontal loginFrm" action="cek_login_pelanggan.php" method="post">
			  <div class="control-group">								
				<input type="text" name="username" placeholder="Username">
			  </div>
			  <div class="control-group">
				<input type="password" name="password" placeholder="Password">
			  </div>
			  <div class="control-group">
			  </div>
				
			<button type="submit" class="btn btn-success">Sign in</button>
			<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
            </form>
            <p>Jika belum memiliki akun silahkan klik <a href="register.php">disini</a> </p>	
		  </div>
	</div>
	</li>
    <?php } ?>
    </ul>
  </div>
</div>
</div>
</div>
<!-- Header End====================================================================== -->